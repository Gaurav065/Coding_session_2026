"""Project Peak Tape: Validated High-Density Animal Strategy + Safe Aegis Overlays

Base tape: a real historical submission that peaked at Elo 2153 (main (1).py),
independently found to already embody the exact pattern a 456-player-game
corpus analysis derived from scratch -- early animal purchase (step 1), high
animal density (8 cows + 4 sheep across just 3 quadrants, not 4), and zero
investment in tomato/carrot/egg (all measured with ~zero or negative
correlation to score across the full corpus).

Wrapped in ONLY the Aegis overlays empirically confirmed safe or beneficial
for this tape: weed-repair, feed-rescue, terminal liquidation, and a universal
exception-safety fallback. River's trickle-selling/queue-conversion logic is
DELIBERATELY EXCLUDED -- isolated via ablation to cause a -$86,730/game
regression (56% collapse) when applied to this tape's own well-tuned sell
schedule, because River's generic pacing was built to correct problems
specific to Aegis's own tapes, not this one.

Validated (env.run(), 8 seeds):
- Raw tape alone:                          $152,204 avg vs starter
- This build (+ safe overlays):            $154,824 avg vs starter (+$2,620)
- Head-to-head vs raw tape (mirror-ish):    statistical tie ($88,449 vs $88,966)
- Head-to-head vs prior Aegis default:      WINS 7/8, $109,673 vs $86,560 avg
"""

import copy
from typing import Dict, List, Any

TAPE_B64 = "eJzlnU+PXcltxb+KobUXbmk0trPTSG2PYHk00J8MnMFgYCAOAgTOwskuyHePWq1+9966P/IcsupJNrKaN3r97q1isVjk4SHrx/959G9//ttf//K3R//0ix8fff/s7dtHP/3yF4/+/c//+a//dfdPd//z1z//7T/+8t93//fjo2/e/+nn79+8fvH++btHH7764dvbZ3cfbr768Ic/Pvr25ZvbR8anu6c8++7lH5+9unvI89c/3D0Cvnn77e3t9x8+fHX57u3t7Yu7b/54++r1dx8+PD198zCkp7t3/vS/v/zFcaIvn//h/ffHl2+T/vHRD7dv390Pdfv0/NnD8LdfbwMcBfX29tWr/XB+G07hSTiFx9nAL6Ifhv7d6zfvvr0f5+7jw8rSE8bBn176IIPKa755//LVi58//P+79x9XIH/D8NfFGb169vx2vxo36nWXX/Dqf/j6u3fbEo1v3hThd3cLpl52/0eDfj17d/smefD9J/Hghz8PZHWZxf06D2/49IdKUCeDwM/dzaerAjSb3WNxH9YXHuazPTmXmLXYNIu3r98/rAnKqb3YpKe72Vxe0F/r/XhBOEvXejO520tXr7UrsfZa2wKzFp2msIkE5XQ/m44yXYa209fTP3ZkvjfUJ+l3VaghmkUqdBnw7bOm4uRjJyktOBmEcJrPPf4g9LfUDw0RXf8H7U25+gexeVQ/fP3q1e3zdz//7vbNu5evXv7L/TKDfyCeQw5fX/FgUOIxFy+mPvRY9adl15jIxZReYSn7Ftn7ZV+S1c2+8E2fb4irf6Bj74eQcqcSxzD3HGRDqP5rxzp/KVMYAwzZlG46cfLm9nmGhcI4iqXDJ4bD/9pbkXMYPG1CHuY0fy7s/IqObeehusPKjovJgW0Ssqz2xbWakRBKORBQf1SneMveidaA90Fve4w76fcll4ZGpWni4kYLYw04gQsa53o7au0Ho3WXKI+plhw7raNyBF9vTt+8fffm2Q/f3L5586ePqO3nOA3tcOoQZqfSLJ2i5RkVjt3x0/rzt3BUWuftVY/eVafwBT7YqWvDKQFtcIO7AWOYfq883vOTzJrHthyh/BaFbYjDWM/GYDJ3DFYce3pKgKC3hIcLzeg5HpLTSoWb0juP1diTxEznySfPqOAkkRuznRljoqVhjHYPG6HGzti2HXOPuHb8lNU4Z9HBkGloO0rNd3QpCf7/6ETd3CJHamaIg5bcemE/rNLmXgygmtw/m5epJ4/x9Ef1fPbmn4ccXMck4nLESbjWK/RhW5QRvgYfN6YpO5b0FJR3hvyQ9pJ77+9yXUtB/GEGVTntfhysATIpahKLYYDJzZunELfUZ32RK2EELnN36XPkYbGs4nB8arzjI/RjpyO88huv706FqMxGFGR64UI64GxYdfa0Ho8qpH2xNnLCLlKbPIL2//qBZ+aBqXOg5VxhfNt4U+pgieelXEnyr6xVFZTICUmT+hUk7QXJNqPMkzH5OLuDezv+rIg03zGn56qnFbZFiMcsZXN0zsyEl3CUcHukBqR3DTLV2tO3jcuIUdcelntOu2UriQDo7cIBqazjOr+nCmJ9OfToSWgBq4d8ELzwKz+3SzK7tIeYpYWrVekoFfRKpAWmEaSxBCA8yc9FLDdAHiod71XfQaCIVQ6PXoYo4u/zD8gjm3CcMHvUTnvZcGK2KVRevJJAWu2pVZ0relykE9YDX7x5/X2sErkjuduAr1/f/fe+iAxPj62K7MMh+QJOC5oZATo8EAqpH3uH0/bHRRNR9LJ1QL09cFO44kvS4Gv3fEAqR6elWO+Qx2dYRVbVVXEqu9pSteJd7sKE4/VpP304z3Kfq/Ip3iK+/1sBhe7f8GTQ510Ebafy8m0PIz/X4x7OgHOt69Fb9OUxl6JkKdwkf933SlT20f1orsAkXMZDMCLmNWQl2z0M7VmbX5RqIEhV2ESMsKL50fnTQRRJ/04HkxDX4Bwpvyv0OhpqCEcZWzCblGWfRMJBR4Ep/eusoEh0Yp62olXzlG5Kk0pagEMEK/oktGKk6+DQBeo9tfWQg8cKTY4sef5rCFwJnmz6WCJUqmhPHmuINL5xOkzuPrKfo0sbak3AWzFjcLeqD72zYZVEr4e+L6PGwNm+9WuC+wpHtCnXi5e/j4bWGAHONG8TkSzFbv0aY1HnkPp+xZvdT1DzP6kL9TFUy66asP0YQsZhTzd8bCQCGlSCXTeD4I8J0qnHLaOMDpGjGQKqYCsLgpNRFxWR3304FTahmgg75cRahenxACcqT8xCy+HZm8TAcaupz9OqfpTis8yPowEavOGOIce1uqiVUtm2tpALvb0/PuDEgHz6Cx3nJ2es8TbShn3OOpBHuYLVpYijgx7H753XyiUO3cjzBnA1D8MSdKZ3L9/WBoJ9T8FEBogcN+YPdJwG8fLAU9P2ul8QBiZj2Ehpv7OJXGLqAhsIzk5Cgc5FRS4rrWDmOw9+0jxFjQwdA3T2Wp19CugvYXfPuoRTiJItYCId+eMwSToVFrxXdDGk3l79KvmYSvRRxp9SxGqGBQy2F8rc/OonHac4nxYw5EVUaVEMG2HR48EmVaKiyYq53HUxgo2ZlFbONVGBxERIUWGl8DBIU65QXoiejBFU+AeNsuNAvnLdXR7yBJPK5iYFlUJ+/fLVOhSQcCjeKaaYFmjSptBadyaq07MWCtnbyZX0hlHIKil/aAk3D99HbuigsqlGCOzrYVf/8eWrP/DpLQIp9EVRcfNUmzWUXGi8Hlp/z+GZWDyMdFhxjMg+kWVHgTlNRP9Y6mWhV8fFyZkPGQSKKwJActkOLxGx4mQZY71wcrd9tMldUDLherzFkMdpfeHt0HgtFylGvh7T84420wPx7zcfH77RZT9q6OeJe1wZxHIZJ7cNg8O6r5uTotsqfp1Ntx9xIeOlGnJRkh4zXOIPV1Sz7OBMKOFSTrgYvyKgrSjpRUwUnCEknqhRFSawKn7Tlm4sigsP0axc4SqzIzeMcLGJcJTEkKcyC5JoTI8cWqlLuFp454O/biKFW4yMT5dyRJuJFU/G1SqYqoXYX82F2KyYpsMT3JqSX81TSSZM1Slxi7P2nsNiWpaAWuFRQmLSSYf64xCPQQJsD38RFcOuGtqflSJIx0HYsdMjFj1Na0PsMbYLiwgFbnCJ+D75Wp/w+JAtszmxFtNmuzPNi2vxuhaD15vmdMffhV+ozHF+lY9FZnUpSAIFERQGRfdI4LT4R2ddndojieA6hk3xDLbvt52EoIya5nnPfJ3uifN1gYe1h0zp/M4QyF19Zyg/uiXJCaWPLJ9UYuXEoQkYrbA0ogQQuQcGKjLZN6KPB9OToKSLzqgFnNZccQqSMU6OBeWnt/O87MKgxm3mBhEXYxY5eoNXp7lZ/c2EFRVWiJMGGgDmKfgkHt5XSmMFcpDQ0cQ82hCKgYB0fPQYxFC/RCaduaCxuAijq6wNpsma4uplSOv8J57gdbDQtJDZBUPJwRQIIasxwAE59MkzmcIBoxEXFYJHJlDNRQNrQ5WOR5gaiQA0SWo5lTlPgclrEWUi9e4DdAxi+6SZrJozHNnCzqyRYgQEBojLFZ5WlfISBm5eaYfHpdbrNlskKbTu6LWkLwDEK0ataD4O2JID/qI/Fi2aknSHEyRR0ry1tsTDOY8K0BC5cQLQoW2o8ijllAqNi2jdwqdXwleZLGghZ/rCBkBiMH0MCpuCpdtlIHIl4yZUp53WZyypAhUbNcpjDptl2bFgKkuQ588wHKr2DWmGrTPRxtmwiUGSj5BcxTN8inxOk6nUbgR2nSBtTmr1d7nUriuJqcsnmxHTaOn/ocN7NRkjvB+b74bFJZi1DRrrVqL77W8Pbsvj7Mt986VRBgQBiJTjSUxBH2EsGFHIuWKHFzved0peTEL43MAqFAtVmaNipKviGCyMClG8wrRqx3X68qJaCEf+/+WXh7NdDDbYPAwT521nvMZT/LGzj4oXKgXk8JyxWa0+oX2VF0NjfYXbLmAUZu4JW3z/qUbKoWhxjDEBNRr3WErqZZThjdbWQ5xEtiLpazRKNkcZsMZNkdVWqHK0yzCaCxgawd70dBcymK1bZHErWurBEo9r92MvyOjQQzG2xCHRIotVK9tmmRoPNp0g8G3fD+daMazmG43d4y1ae/LLPBJWZ7hBhZMghQmb3KjIIiWENmyIpJdq5raHDovf31OErCISxMsIbLLkdppYCQTFrHqbNAbbaY2Bnbn3VILuHqgPaiaQnuhMcbG39wHvPwymMM5nOT1gRXOKIhEAm7Xf/cQkuzR6tFU+flY+QKGOJ67Hu066tNwUI/Ho/B79bqp0ggKQE+rFwgvlKzBTedfMyi9XTNrtpJbC5y/v6mV3Dhjhcp6ZKKRtfaHnKUe2BktY8P3GbroPRk5HKeeTCk0XVPIwybd2BqGStkWGdmcI9Li8+sMeQLtHiAT0+mlyQkYn1Qd1Jmctjv8mRtATUsAtoc1cM65rOngEKYjWXR7zrUX2wWBaurr9Y9rbccGNLY0mGDIPYVRwzjeDdDLH+t+ulfV2398MAxVDnUJ7+jdB1b9XeKuueXzGZ2qGmAf+aqJT18faESj5HCuadaQZbMtdENc1pS9A917X8soEydxxEN/oHnk6rZ4T17ppjAYtoK9SnIoR9m/Nq3B11lkmGuwbVIdJFjvHFaNumQhr/EFj5x1Yr5QAPyqu4oJUYwexnUSGVKXMi/h8b9M4HFdM1sy7qzbMHaZhjqkhEl2x5qOa/mI2aZ6jwahV1ei3oxG5JU0Pf514eEToyYvWT0XaU6EQwAlpvVyPPzqwt2ivSns3KBA4bJzp47oXBke3B6ypTyDTbLc4RW0j6+nBKyYmK2oGaFs4KfPa8oLTSPEuc94ru4YmdiKTTy1yjvAauLGfgxu6P/5mQoi791PffsWy94b38UVHJb0pgzRI/e+2IDXV87MG1tEng4xkCi5HvOJ/s231friH1Q9nQwagT0WnIKVPRcdUWUg8F1Y57qYASiZp5uXq8vj7Ng6hss0h6tCJ56dY5RwSSvJ79Le1I+7pQe0PSkPmpdJuPy8ek5nyFbVsthfRLhue9hcLm8lwKQxSqVaW/v6i1Y86Zio678VvW7jV0pbwoTc5k9atMHHzavSjwgYBA/yzGKDgiQs2rWyegaTiMtwl+mbmSWGVn29kWwXwza3UCjdBBk1p5rNemrNP2hg1miuvo94NSooFxsOV8V95NByktoUv8qJAL41MLF4sVBCw2647ifRbBXYhFh/L9sWzaWcLzHDBhZZqa5SaddjtL+J42W5ftvu4KZzN0LeSyTnz3U1FTQELqoOsm24vgeTBOdwM3Y/BaH1C42vOEezwzI9TaAf3Q/52AYGlSunujd+5KH7JCi1J76ewQL3/XIAFjPjCEPNFe1fn9Z9q5lO0Ek9Lwhbel4GG1E13emJfK/NvEhRyrrKHsLQnNJV65fe0GAtiGipnYtFAC6yGYGZtXsMh+gpTvcJv8YNq4fAeqjYowYKOj7fVVBPzPkECuQ8Y1gY+uij7r5BdF7SmQVH7jArUFSPoKyAzK8psdJJKUDKUORBNfT11y1GUsFF7hZoR6exh+wnyTCkOpuojTG7fZvtDYi6qiQtvKmEYI+M+3OjRR8MCeD4ybxJ3UUUmInaUl2ooVkK6hoKEEuRP4nMq2g9eO4a8mmgBcUXyL1Jh8dko5oTZi0jEeFaWSC+K8FfgOfl7S81RWA9NkWFsMLSQMe+eDKRReIubDDXMKCsxuEqosnzh6kwyha5UrHSIMBqkiKyhTYqxl0qUgaL6kxw49IrIt4KU7YCo+cAlSMV8OfjDeBK0GKKXw8Ey3NxjDGPnAbgnSxBH0oOK6lYWEBl9FspIe7uftame+X3GFu2p8mnBpcB/1xU9nct9j9BhCBBes9xnRceJUuGPWONljSXy4VW6O/x6wrRj6wkdqomBroyCSaKC+ZrzLsRQRXOJwH+pXHKb5NCi9e5WprraWuqZwepTTfG5uVuRqmI8i6Yz5knH8aUNKobBt2hhpeIvdmcUepA4hOmFnZ422clra2sUbkCZ6Nvg2rECVdLW773iKHACR8+CiTSiVtq0RLwifMl7YVSaz1UAOn+kugWhIE8Kn/+YcQOjgdEyvt5YZzwLg8lWghVXxNoU0HbrSLiKydKn2sapiLFKQjP4qqKh4z4Cl/BvrQWHwRZHQ04LXOnr+mBF68Os0DHJkRQSbiet0H8VlGwK2gbZu6gWhdN7PgO1r6zknTAn59H4zDV2WMBxg47kRxZ4AVHWWaSePR0Lbq7aVXKu6mpyaF/4zgr0+VLWTxKgi/0V1DDMcydFlFbmptjdCUv2fnKU69oXomyFdZcdyZcOvx0o4tR0/Y6TRkEvbL4OPN8QpRKBQkG4nzyuVyKJirOjsgm4L8t3NzaxopQF52dU3qJ7aUxHapWyJUVXqqArMs8NS7B2iwuEKnOmYttVqEqp1FP7PDhjG0ebxsrwnvZT3zQJ/qwsUFFFciaVQmxzUcyCGs3t59PJJHTfvoSbd8eEBquEblmUMCs4gWJ+JEiJ9c4v3/Bqt3ar218Wu4xQ3d1S4VFKysKY6AAz5GNOBrQTYajaMx8jK7GDbXEHcI7dNTzmVQgFB5aSaoHsgNEE8JHhLwi3m8h4+NIgHeDMcxLJjluRh2/EnXHXKkmaCcZVUuUWDYVpMeZ1rY0TjcCKQC2oA07tk9gN0MjxC9M6amSOeKJXuM+kz/BI26LO1IAJ25hWQ4U1XcPmViwNs4VMDsTsT08TsVIZcFEpNEHvSNUWUaISXdwe+DUKtXQbDdGqUB976HTlPxPzslkspXafvDovXv4+81ECNs5sOwLaPUFxf1ScVao4y7t5cOh9kYy7bKLaMQh18oquEFcOo6Wk3Ua0cldoPisZMHnzHFk9AxISc8IWBDosHaRbSt/zTlWFXWKT6fQblinI0qQ0ux+lgSmVmdnK8DKH06V54MrhvJTZMkwkTVPV3O0+XuxENbr/+BskmLv3GzK2dVgJv4hSla3mVaRyZaGE323OIBeeFFq4MLKjGMgy07X6NsXQr3vM4zmS21hW7LQBmqna5q1vEZP5KHOwS8ZRWYAQ9RrKzYlLaelRyYNTRW+aJjfjgeoU9wS3EYOEWGxtz0atVJ4tCA6/yHwIfHBhzkqul/A/bPORULKFIZlcmNjBkLxr3vJhpRgeHH2uoBEhN41AUlR4/Po0o8Y0BCYp3luv4xrL3zzbbDVvth71+Fc/7V2UQ5fhfhuqI/NJQ3QTd5PNlYyt6U/11dckRCLj/f1dLiVhR4ksmr+N1PGhTeJc+lvjVz5bTXxd5X3neInqrqvutBUYagWrtFLNVMhXgVHyUHy3r3PgROfipRBmnMTo/KrVMBtsAY1BCPfF7eocLvvtq9ff+RQD3EbacewR53wnzmOyuJWI9DLaqUEvWXWXkk8WaSxa7vQEPKk0tyzagYQhaui4LyR39lMnTHlb0RYO/3FXEwDiRI3JHcYHFcA4nlAKEdk5GO4wJw7G8PvRplUbV1ZvZ/MO9uS0DRjcAaYzLhoLorGbxeRQwchSFVoOqcbeduHhRUN/VZ6XJvSI6iWFXuDMuNWKOFMw4M+Np1e075DGtkV3tFRWGDiFe7GuGsUnvpbZ7mGQzCDBFGrC4lmeByYZmDFGL4vOdYae57dOlQsk5OBPhRc3DDXyJcsaa5LtKJ8qjuiAFkYpKpl103HtWUfEMmKHBLXzKpdiCAcijEioutMCVfNGg9HK5G3CCqmHPWB/eeYpP+nWwCK7Ex0I0DG0awbPQrYbKFDSH471Y6/wmLooJpzWwx7HHsRbwROOypAWXo9hjz4X9lM/Nk8nu9O6SoCh4eGaxIfFuAcA15EqJxBbxZ+eRWe9VFKl6vf56x82JgMerZ/ndsDTNS/Dp0hDBk6C65lFk5KY4mKO5zitVa2lpJdktDWqsj6F8c/RGcMHVEXSggJhkiH4gg6jY8KC/lPBdAMjj6roJFk/0p3EaimyEsnaKFaw+pzHS5ywD8V8AjsgnbhaOax8XAAhrYBwK6MQ0aSdZ4qscq2xCCGvcef/dMK7v7yQ+kRIk3D+zrbgOvcL6AArWgbp6M0xbkUaJHCt8Ri6LMfOpwXieqR6js2iWOmb9y9fvfj5gzf27n1KJkTKiBBoTklH/SxaLYwfPjzj+e3ou0U6Ucrm4eBh4VTEdJrHw9vYdOWntb4SMLBt+fKYxRCmO+D5COep3MSmUMEWfCzyR3maTpc153kXjVjwsCz4MIUzGmeqbG2lk2ZoYi4bafDRzlUqyYpwZHxkOj0sk9mYOFAZWDy0AJUjyLqS11ZC2HTU5LHC4Yh0clv8Qlm+QWGczgJrmq+KF0SUge49fGr35dPo6Q/yNMsLXjbkkibTHjj1uitVt0lkMqeM5knysffpfrMcjAftmB5A9+TeDF2h0Nmls16TRenvyQ4VMr0Rc7osuwzwNI7NCjPPKt3JULfGdhUFwYI6oMfFqYOlfB6BlpH2G7xBEdVPkQa5rqtNNVLoq8jfHDaVefMauq6YS3NQEwYua1AwuXomQCyjA9E7z8W3prYnN8CFXHOUn3cLO6e2IMuvdA8F8t5jB9pUEEgIVQqn47I76YXp9ThhDWJBfBRaJrJzsY9uY2dc7rXIUXwroKN+cZxQPun4S/TA2/UoNFMNS/WzYtVP+hEdFxfj6hY0y/NVBo+Eb5Rr2D5ZPaNfZC3nEQEwM2O1OWXRkZrfceEH5p2NJU4qeWblYavimIb9ESvmPoo8K/ccY+1iQ8agt6IpWhzPH8dFf2f5url6FtqlMURADv3pHzua6XadF8OKo2ihlXRvRLdd/xy/5/hJb5461LDqjr/p2UBEsxyKeDoqSxWKCJ779bBP85jDKt4Q+2bZTYLC38z/zQc5HL6hm11H3CPrvqFQowpSYtKFPuuVhRoZUX9LQIuy3C7cYKDKeFAquIT/9Jx3D6cUQCtwj65NXgmgLS9MqDjggptfDMTPdHsw0GU+TBQqqp5zArwJa8AqZJHPU6toVARHLBkxrWjvjhp/FJ2qLTYp0Dmtn0epA9+snkRleUXmthztI3Ulh0iIjSOSx6qyBP8R1MTb0lW4JQYxSuUnqsyvgIMKgPxTm2sTGjeYbYHVCgsPFegUpEzNosPGtGmB+QS9yFhhxGo5c4JcsiHq51J8nS6ud6TYaJUr184aKUC3PlI0/TC3cOmyC7JbE50s1DlgmK/efs4pP6rknTcsk5vo+cpGTZnkarJDZKPsCk8VJhbMVXGLKtR5XzQfnVKG/mnNdbuxDKSUu59qAzZ0ka+CYyHxunIJWnQSEbQGZNoq3oeOVWh4NhY8gKEuWx6nItyxU+OVlh12/UBs81JiJtIU8fvTX4qJIRqfN3PIyUs4KtrYOUQpXMEjwdSKXMdHfUEiGAkm/rfOwKeqLi2o9cl4VlQLMclDQWQgr0rsdLsQzlx8hKhfVslKnTLJIGixezFHj7penaR/vyr/PnFd1GjbyE7k8+skJMfRfoc8dRLlui3cPO06RLCMwjdyPYLc1t5RiiOBYDcXwFlZiSKhmQJtD06ivIiDvPbY/hh9NZUn3NnfWtMpNiE4Lf/kIN3jMrhdHaQlQMdTtLgKDgczGBVbhNpz0e6Pu7k5fZ8r+B7Py4z2OzkY3qWiDqhIKq5WC9r0UP5Iu8Jp++7s5oijAIpUIZNmwL1TERzELGm1VWfbHwsdjyJwL3PU0NquUE7dLi3xYARbJwJtylbkAWmv/2BekHGyZMf6noMhIHCXYu0QkzdSUBoFYjtzqkLu7zawGapHg2CRWDX3o3lsmDado0JzjNh4DSWPpH055UHQ1B6JBHnZxNsa0ycFdleHDKQYhLqD5cy3ck7lQQpi3HtC7OibDOgkvyXHzwTO5M5MNDNRc6JmVZIV2OfFKXQ4D7W/zCWvd5/MVEeH3HeqB8zwpYjJ90SdVuMR10WabNZQj6SnWPHF0dpcHk2/Kww3CRnUeFf0rhEcu36ooOAOnRw6QtjQDSEn4DGPsFDgpQDR3GWNbOmx5Lp8tUibalfgU9Gpt/ouVjimRPFi6rcZM3ATmcCX5suDlgEreLjjOV9gzUhUwkZbxn2IErmpnHy9EmSLT5oTKxmBSiQllLxV4Eh8Ez6/dP6+zOtDPzPflwZI5nJ6LM86sTK2hgWouNpp4q5WndNaSPQqFjNV7tb10Q0RpQpMxmFQo0LKPISBuMvFEo2RSh2caGJpVkbxeQ3HS+HxjRI+QU5h9UbsFhVH/h7wwEj+Q/nRJDFQgctoqZ2EFKvvPPUzrhkLTF/e8eG4eAKlcustZGZOaOOswRPEOXEEKcpvXtofKOp9K6B4eQsXzuaAEW46I/rJ0SUDXs2FccG7vdssuEA3L9YWoJn2qwvLad7K4Q5z5tNIEBR7S9O/Ti7+XHswC4nOa3GvX5+7EKNb3wvs1OJemGkbWQqUG7B4AidK/C+B01VKRSoVjVaTvFaPMX85NoK8A419yaZjhVIBcYbWJmg60ddtVmavJ3uwQis/8bgaV5aSCyKiM+nMlIIFZxIKvMzdTkkNcWggCqg8H2wDohXWVHV4LYSpRxPKQZSc4d/igO2nPRxSX6a3GnBIcD96paTRum/sMVh39ybLEuVvh/hJ22XTlDNYU0zdbYilTInfqk11NdC9s8stvMLLJOXN5crGs72ZwF/VqtIhPfZGdExirFt6r1R5GXhKVU9jiSrQqnasQ70xN84vUHOya7C4THZr5yGMKyujtAKlQ1XBWMkgsoXOcZFKttgFBBXIoymMaO5UPFbNM5HrkePxuqJOkNNDxlybAyzwduOqJq5GxoUDQ0nFYsWB+9mDNIeOi7PDOcIazshMS+UXxEVsAShYfjnXDmG20z9G8+kE7yKSrQ7tKBYfejKukbEb6X16xjFAAX7CiiZ0RxUqs+1qn8YJVwbmT+kgKeAP6ZJP0Yhpdzhqpl72x1El6JPhl14FXKXAkybT66B//uhZK7P3eYEM2E4Oiz4m6uiQIbIkb+H5Eo1KtxTzxo3OY+USGukAi/rWKa2WbBtCmiL/oRqfNDwj0u2EMH/8N+c6S3fVbCKfVGujCZ0KDH1QcnuEGLeoBJRs3AodMQUSxDiRc6H5teSvsEBx9y3Q2iiaiHK1FcR9ArZfp9cYukmlzSt48zryn4IT8xM42YBhZO8AVSiuiEoCbFU0HX34GD0C2nd1if7yQoNw7JrCVeB6BnalbmQo2S441NjiaPNhqbNN/MBIPZLKIoo3cqqYqxVkOvVFq+R5iWn99l7JzBQLrZFOfgnGDla14T2moJgNpRKgAYWE+WDZv7MSe2Qu8/pHp3I7R9v2fdnY28yH/snQJyG/2YWYBpeXxFHnqXy9vERNLnJ3dHk2xB4dVMnOXKB4ifa/jhesg9EsvddgBUdqyn1SpIrojmgTPblJH7KikENHw1GoYgbMYnglYecDrYEjgoYuhk1cSKULEhgplQHVaORmp+/IhdTYjKLH5Y6sODSAC06jL5Qn1cpHXT72KqVBH0hRFrLvI/lml3XjFfIbBuxlIXXXKiNqcWtUO+J3MSVVf9cM66Xih2ev21NWZXGnIbhiQh+jehVMKsuasib6tAhZCrfvUzt2jDkOxyg19IwIgmqM85UqsZw7GayI92gwpIMvz/+go4Cw8Cj5ApgZerzVBj+KSUbb02r5XAU6RaI8Y7MkapM3LfJa45hx3+b2E4dSHR00ULvL06UmLVRtuuIMokNReqSIC0fyG0S1hSKIY2eujIqfBmgKuQ9KkXiHnPgN0tYUpT7zKWkIaQmcCp/NSqH8Ux4jj5/UbgQoO5dpdyCVYRrHtZrX0+RgmiebSFQh93us2qb8DBnnL0dUAfnFGUujSlp1qrXN/VgJXgix9gcWFSALx7ri3sZHV3lDuMXbIlPjtETPz/ljj8SkOgO8qwrjR8lRqotibpyzO3Dsq84phvvNu01PyctIuWM26LXFCibBheiYhcqOUsT2fIf0bEMkRJX1jCc0QbZuAFD8NgMeFthIY6QWW8zaVNZxJUYotrkoYOz3q52TK+4hmwVOcrMWYmYHGZi0lqv6Xf6EhrLyvqEXKqwgFr8YFiJFyg9S9R2UBS8nJonHXxitJLgZYBsXsn+cXDR6BWWpGSDhIm9CjD85/Toa8Hbg7z2uSw7RXYR8YDtUBr5FBt+pNETpS+YzPsbJQaz9MCin1jWs2qPou/0MXF1tf0A+kI7JKSxuLJ7/YvxWjTPhftwlKH/6P6JePZM="
_TAPE = None


def _load_tape():
    import json, zlib, base64
    return json.loads(zlib.decompress(base64.b64decode(TAPE_B64)).decode('utf-8'))


def weed_repair_overlay(
    action: Dict[str, Any],
    obs: Dict[str, Any],
    step: int
) -> Dict[str, Any]:
    """If a unit is about to execute a tile action (PLANT, WATER, HARVEST, BUILD) on a square
    where an unexpected weed spawned, swap the action to DIG for 1 turn to clear the tile.
    """
    player = obs.get("player", 0)
    farms = obs.get("farms", [{}, {}])
    if len(farms) <= player:
        return action

    farm = farms[player]
    tiles = farm.get("tiles", []) or []
    farmer_pos = farm.get("farmer", [4, 4])
    hands_pos = farm.get("hands", []) or []

    all_positions = [farmer_pos] + hands_pos
    farmer_act = list(action.get("farmer", ["PASS"]))
    hands_act = [list(h) for h in action.get("hands", [])]
    all_acts = [farmer_act] + hands_act

    for i, pos in enumerate(all_positions):
        if i >= len(all_acts):
            break
        if not pos or len(pos) < 2:
            continue
        x, y = pos[0], pos[1]
        if y < len(tiles) and x < len(tiles[y]):
            tile = tiles[y][x]
            if isinstance(tile, dict) and tile.get("kind") == "WEED":
                curr_op = all_acts[i][0] if len(all_acts[i]) > 0 else "PASS"
                # If trying to plant, build, water, or pass on a weed, clear it first
                if curr_op in ("PLANT", "BUILD_COOP", "BUILD_PASTURE", "WATER", "HARVEST"):
                    all_acts[i] = ["DIG"]

    action["farmer"] = all_acts[0]
    action["hands"] = all_acts[1:]
    return action



def feed_rescue_guard(
    action: Dict[str, Any],
    obs: Dict[str, Any],
    step: int
) -> Dict[str, Any]:
    """If live animals remain unfed late in the day (hour >= 18) and shed has 0 wheat,
    automatically dispatches a BUY_PRODUCT WHEAT order to prevent animal starvation and escape.
    """
    hour = int(obs.get("hour", 0) or 0)
    if hour < 18:
        return action

    player = obs.get("player", 0)
    farms = obs.get("farms", [{}, {}])
    if len(farms) <= player:
        return action

    farm = farms[player]
    tiles = farm.get("tiles", []) or []
    unfed_animals = 0

    for row in tiles:
        for tile in row or []:
            if isinstance(tile, dict) and tile.get("kind") in ("COOP", "PASTURE") and tile.get("animal"):
                if not tile.get("fed_today", False):
                    unfed_animals += 1

    if unfed_animals <= 0:
        return action

    private = obs.get("private") or {}
    shed = private.get("shed", {}) or {}
    wheat_in_shed = int(shed.get("WHEAT", 0) or 0)

    if wheat_in_shed < unfed_animals:
        needed = unfed_animals - wheat_in_shed
        money = float(farm.get("money", 0.0) or 0.0)
        market = action.setdefault("market", [])
        if money >= needed * 25 and len(market) < 10:
            market.append(["BUY_PRODUCT", "WHEAT", needed])

    return action


MAX_MARKET_ORDERS = 10
TERMINAL_LIQUIDATION_STEP = 716
ALL_PRODUCTS = ["WHEAT", "CARROT", "TOMATO", "STRAWBERRY", "MELON", "EGG", "MILK", "WOOL", "FERTILIZER"]


def execute_terminal_liquidation(obs: Dict[str, Any], action: Dict[str, Any], step: int) -> Dict[str, Any]:
    if step < TERMINAL_LIQUIDATION_STEP:
        return action
    shed = (obs.get("private") or {}).get("shed", {}) or {}
    market = action.setdefault("market", [])
    planned_sells: Dict[str, int] = {}
    for order in market:
        if isinstance(order, list) and len(order) >= 3 and order[0] == "SELL":
            planned_sells[order[1]] = planned_sells.get(order[1], 0) + max(0, int(order[2] or 0))
    for item in ALL_PRODUCTS:
        available = max(0, int(shed.get(item, 0) or 0) - planned_sells.get(item, 0))
        if available > 0 and len(market) < MAX_MARKET_ORDERS:
            market.append(["SELL", item, available])
    action["market"] = market
    return action


def safe_agent_fallback(obs: Dict[str, Any]) -> Dict[str, Any]:
    player = obs.get("player", 0) if isinstance(obs, dict) else 0
    farms = obs.get("farms", []) if isinstance(obs, dict) else []
    me = farms[player] if len(farms) > player and isinstance(farms[player], dict) else {}
    hands_count = len(me.get("hands", []) or [])
    return {"farmer": ["PASS"], "hands": [["PASS"] for _ in range(hands_count)], "market": []}


def _agent_impl(obs: Dict[str, Any]) -> Dict[str, Any]:
    global _TAPE
    if _TAPE is None:
        _TAPE = _load_tape()
    step = obs.get("step", 0)
    if step < len(_TAPE):
        action = copy.deepcopy(_TAPE[step])
    else:
        action = {"farmer": ["PASS"], "hands": [], "market": []}
    action = weed_repair_overlay(action, obs, step)
    action = feed_rescue_guard(action, obs, step)
    action = execute_terminal_liquidation(obs, action, step)
    action["market"] = action.get("market", [])[:MAX_MARKET_ORDERS]
    return action


def agent(obs: Dict[str, Any], config: Any = None) -> Dict[str, Any]:
    try:
        return _agent_impl(obs)
    except Exception:
        return safe_agent_fallback(obs)
